
export interface TeamComponent {
    name: string;
    jobTitle: string;
    role: string;
    goals: string[];
    specializations: string[];
}