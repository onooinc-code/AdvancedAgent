
export interface ManualSuggestion {
    agentId: string;
    reason: string;
}