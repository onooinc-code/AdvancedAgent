export interface PlanStep {
    agentId: string;
    task: string;
    rationale?: string;
}