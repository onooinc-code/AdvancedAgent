
export type LongTermMemoryData = Record<string, any>;