(function() {
    'use strict';

    // --- 1. STATE MANAGEMENT ---
    let conversationState = {};
    let cumulativeChangelog = '';
    let isAutomationEnabled = true;
    let tagStatus = {
        GET_PREVIEW_STATE: { status: 'idle', last_run: null },
        TAKE_SCREENSHOT: { status: 'idle', last_run: null },
        GET_DOM_STRUCTURE: { status: 'idle', last_run: null },
        INTERACT_ELEMENT: { status: 'idle', last_run: null },
    };
    const features = [
        { name: "Conversation Lifecycle", status: "Completed" },
        { name: "Conversation Titling", status: "Completed" },
        // ... (all features)
    ];

    // --- 2. UI & STYLING ---
    function injectStylesheet() {
        const link = document.createElement('link');
        link.rel = 'stylesheet';
        link.type = 'text/css';
        link.href = chrome.runtime.getURL('style.css');
        document.head.appendChild(link);
    }

    function createControlPanel() {
        if (document.getElementById('ai-bridge-panel')) return;
        const panel = document.createElement('div');
        panel.id = 'ai-bridge-panel';
        panel.innerHTML = `
            <div id="ai-bridge-header">
                <h3>AI Interactive Bridge</h3>
                <div id="ai-bridge-status-light" class="status-light-red" title="Status: Disconnected"></div>
                <button id="ai-bridge-toggle-btn" title="Minimize">-</button>
            </div>
            <div id="ai-bridge-body">
                <div class="button-grid">
                    <button id="new-session-btn" title="Sends the initial context prompt to the AI.">🚀 New Session</button>
                    <button id="view-conversation-btn">📋 View State</button>
                    <button id="view-tags-btn">🏷️ View Tags</button>
                    <button id="view-features-btn">✨ View Features</button>
                    <button id="toggle-automation-btn" class="automation-on" title="Toggle autonomous execution of commands from the AI.">🟢 Automation ON</button>
                </div>
            </div>
        `;
        document.body.appendChild(panel);
        makeDraggable(panel);
        createModals();
    }
    
    function createModals() {
        // ... (modal creation code, unchanged)
    }
    
    function toggleModal(modalId, show) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.style.display = show ? 'flex' : 'none';
        }
    }

    // ... (UI update functions, unchanged)

    // --- 3. CORE FUNCTIONALITY & HELPERS ---
    function getProjectId() { try { return window.location.pathname.split('/drive/')[1].split('/')[0]; } catch (e) { return null; } }
    function getChatInput() { return document.querySelector('textarea[placeholder*="Make changes"]'); }
    function getSendButton() { return document.querySelector('button.send-button'); }
    function setStatusLight(color) { /* ... */ }

    // --- 4. AUTOMATION & COMMAND HANDLING ---
    async function parseAndExecuteCommands(node) {
        const changelogRegex = /<!--\s*MONICA_CHANGELOG_START\s*-->([\s\S]*?)<!--\s*MONICA_CHANGELOG_END\s*-->/g;
        // ... (other regexes)

        const html = node.innerHTML;
        let changelogMatch;
        // ... (other match variables)
        
        while ((changelogMatch = changelogRegex.exec(html)) !== null) {
            cumulativeChangelog += changelogMatch[1].trim() + '\n\n';
            saveContext(); // Save after accumulating
        }

        // ... (action and update parsing logic)
    }

    function injectCommitButton(modal) {
        if (modal.querySelector('#paste-commit-btn')) return;

        const pasteButton = document.createElement('button');
        pasteButton.id = 'paste-commit-btn';
        pasteButton.textContent = '📋 Paste Commit Details';
        pasteButton.title = 'Paste the accumulated changelog into the commit message.';
        
        pasteButton.addEventListener('click', () => {
            const textarea = modal.querySelector('textarea[formcontrolname="message"]');
            if (textarea) {
                textarea.value = cumulativeChangelog;
                textarea.dispatchEvent(new Event('input', { bubbles: true }));
                cumulativeChangelog = ''; // Clear after pasting
                saveContext();
            }
        });
        
        const submitButton = modal.querySelector('button.submit-button');
        if (submitButton) {
            submitButton.parentNode.insertBefore(pasteButton, submitButton);
        }
    }

    // --- 5. EVENT LISTENERS & INITIALIZATION ---
    function setupListeners() {
        // Main chat observer (unchanged)
        // ...

        // GitHub modal observer
        const modalObserver = new MutationObserver((mutations) => {
            for (const mutation of mutations) {
                for (const node of mutation.addedNodes) {
                    if (node.nodeType === Node.ELEMENT_NODE && node.querySelector('[mat-dialog-title] .title')?.textContent.includes('GitHub')) {
                        injectCommitButton(node);
                    }
                }
            }
        });
        modalObserver.observe(document.body, { childList: true });

        // ... (body click listeners)
    }
    
    function saveContext() {
        const projectId = getProjectId();
        if (projectId) {
            const dataToSave = {
                conversationState,
                cumulativeChangelog
            };
            chrome.runtime.sendMessage({ type: 'SAVE_CONTEXT', projectId, data: dataToSave });
        }
    }

    function loadContext() {
        const projectId = getProjectId();
        if (projectId) {
             chrome.runtime.sendMessage({ type: 'LOAD_CONTEXT', projectId }, (response) => {
                 if (response && response.data) {
                     conversationState = response.data.conversationState || {};
                     cumulativeChangelog = response.data.cumulativeChangelog || '';
                 }
             });
        }
    }
    
    function initialize() {
        if (document.getElementById('ai-bridge-panel')) return;
        const appRoot = document.querySelector('app-root');
        if (!appRoot) {
            setTimeout(initialize, 1000);
            return;
        }
        injectStylesheet();
        createControlPanel();
        setupListeners();
        loadContext();
    }
    
    // ... (rest of the file)
    initialize();
})();
